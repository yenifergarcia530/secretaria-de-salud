
package hospital;

public class Medico extends Persona{
   private String nombreM;
   private String consulta;
   private String fecha;

  
    public String getNombreM() {
        return nombreM;
    }

    public void setNombreM(String nombreM) {
        this.nombreM = nombreM;
    }

    public String getConsulta() {
        return consulta;
    }

    public void setConsulta(String consulta) {
        this.consulta = consulta;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

   
    public Medico(String nombreM, String consulta, String fecha, String sexo, String nombre, String apellido, String direccion,String codigo) {
        super(sexo, nombre, apellido, direccion,codigo);
        this.nombreM = nombreM;
        this.consulta = consulta;
        this.fecha = fecha;
    }

    public Medico() {
    }
    
    
    public String imprimeMedico(){
   
        //System.out.println("el medico es: "+nombreM+" ,la consulta fue:"+consulta+" en la fecha:"+fecha);
    return "el medico es: "+nombreM+" ,la consulta fue:"+consulta+" en la fecha:"+fecha;
    }
    
   
}
