
package hospital;


public class CentroSalud extends Medico {

private String lugar;

    public CentroSalud() {
    }

    public CentroSalud(String lugar, String nombreM, String consulta, String fecha, String sexo, String nombre, String apellido, String direccion,String codigo) {
        super(nombreM, consulta, fecha, sexo, nombre, apellido, direccion,codigo);
        this.lugar = lugar;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String imprimeLugar(){
       
        
    return imprime()+"\n"+imprimeMedico()+"\n"+"fue atendido en : "+lugar+"\n"+"\n";
    }
    public String imprimeLuga(){
      
        
    return imprimeMedico()+"\n"+imprime()+"\n"+"fue atendido en : "+lugar+"\n"+"\n";
    }
   public String imprimeLug(){
        
    return "fue atendido en : "+lugar+"\n"+imprimeMedico()+"\n"+imprime()+"\n"+"\n";
   }
  
    
}
