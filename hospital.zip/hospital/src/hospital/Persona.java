
package hospital;


public class Persona {
   private String sexo;
   private String nombre;
   private String apellido;
   private String codigo;
   private String direccion;

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDirrecion(String direccion) {
        this.direccion = direccion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    

    public Persona(String sexo, String nombre, String apellido, String direccion,String codigo) {
        this.sexo = sexo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.codigo=codigo;
    }

    public Persona() {
    }
    
   public String imprime(){
       
       //System.out.println("el paciente se llama: "+nombre+" ,el apellido es: "+apellido+" ,el sexo es: "+sexo+" ,vive en: "+direccion);
       return "el paciente se llama: "+nombre+" ,el apellido es: "+apellido+" ,el sexo es: "+sexo+" ,su codigo es: "+codigo+" ,vive en: "+direccion;
       
   }
   
   
}
